var config = {
    mode: "pac_script",
    pacScript: {
        data: `
            function FindProxyForURL(url, host) {
                if (shExpMatch(host, "*.whoer.com") ||
                    shExpMatch(host, "*.seobdshop.com") ||
                    shExpMatch(host, "*.rankerfox.com")) {
                    return "PROXY 192.142.242.13:5432";
                }
                return "DIRECT";
            }
        `
    }
};

// تطبيق إعدادات البروكسي
chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

// دالة المصادقة
function callbackFn(details) {
    return {
        authCredentials: {
            username: "8mhmq",
            password: "3azhkvbg"
        }
    };
}

// الاستماع لطلبات المصادقة على المواقع المحددة
chrome.webRequest.onAuthRequired.addListener(
    callbackFn,
    {urls: [
        "*://whoer.com/*",
        "*://member.seobdshop.com/*",
        "*://rankerfox.com/*"
    ]},
    ['blocking']
);
